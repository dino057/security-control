#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QTimer>
#include <QMainWindow>

class Simulation;

QT_BEGIN_NAMESPACE
namespace Ui
{
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private slots:
    void onStartClicked();
    void onStepClicked();

private:
    QString findDefaultMapFile() const;
    void refreshLog();

    // ui jest wskaznikiem wygenerowanym przez Qt z pliku .ui.
    // Tworzymy go przez new w konstruktorze i usuwamy przez delete w destruktorze.
    Ui::MainWindow* ui;

    // Simulation jest nasza klasa z logika programu.
    // GUI tylko wywoluje jej metody i pokazuje logi.
    Simulation* simulation;
    QTimer* autoTimer;
    bool isAutoRunning;
};

#endif // MAINWINDOW_H
